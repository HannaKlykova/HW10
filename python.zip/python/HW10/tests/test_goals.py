from http.client import responses

import pytest
import requests
import json
from faker import Faker

from helpers.session import Session

fake = Faker()
from pytest_steps import test_steps

session = Session()

# base_url = 'https://api.clickup.com/api/v2'
# head = {
#     "Authorization": "pk_2144452523_XWBOQCMLNN5HVAAN3IWLU7SJW1I2YGJF"
#
# }

team_id = "9012323965"


def test_get_goals():
    response = session.get(f"/team/{team_id}/goal?include_completed=true")
    assert response.status_code == 200, f"Request failed with status code {response.status_code}: {response.text}"


def test_post_goals():
    body = {"name": fake.first_name()}
    print(body)
    response = session.post(f"/team/{team_id}/goal", json=body)
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"


@test_steps("Create a goal", "Update the goal")
def test_put_goals():
    body = {"name": fake.first_name()}
    response = session.post(f"/team/{team_id}/goal?include_completed=true", data=body)
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"
    yield
    goal_id = response.json()['id']
    print(f"my created goal is {goal_id}")
    updated_body = {'name': fake.first_name()}
    response = session.put(f"/goal/{goal_id}", data=updated_body)
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"
    yield


def test_delete_goals():
    goal_id = 46
    response = session.delete(f"/goal/{goal_id}")
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"


def test_post_list_from_file(create_data_for_list):
    # with open ('TestData/Create_goal.json', 'r') as file:
    # data = json.load(file)
    response = session.post (f'/goal/', data=create_data_for_list)
    assert response.status_code == 200, f"Request failed with body {response.text}"

def test_post_key_result():
    goal_id = "900e-462d-a849-4a216b06d930"
    response = session.get(f"/goal/{goal_id}/key_result")
    assert response.status_code == 200, f"Request failed with status code {response.status_code}: {response.text}"

def test_put_key_results():
    body = {"name": fake.first_name()}
    key_result_id = "8480-49bc-8c57-e569747efe93"
    response = session.post(f"/key_result/{key_result_id}", data=body)
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"
    yield
    goal_id = response.json()['id']
    print(f"my created goal is {key_result_id}")
    updated_body = {'name': fake.first_name()}
    response = session.put(f"/key_result/{key_result_id}", data=updated_body)
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"
    yield
